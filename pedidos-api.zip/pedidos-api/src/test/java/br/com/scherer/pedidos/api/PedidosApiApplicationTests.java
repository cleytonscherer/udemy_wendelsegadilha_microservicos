package br.com.scherer.pedidos.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PedidosApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
