package br.com.scherer.pedidos.processador;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProcessadorApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProcessadorApplication.class, args);
	}

}
